﻿$pathToRAMDisk = "F:\KC46 Staging\Production"
robocopy /mir /e $pathToRAMDisk "D:\CurrentCSDB"