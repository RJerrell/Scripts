﻿<#
Title: S1000D_4.0.1
Author: Roger Jerrell
Date Created: 10/12/2017
Purpose: S1000D Modules that hadnles all the heavy lifting of working iwth S1000D 4.0.1 data modules
#>
# *****************************************************************************************************

Function Get-DM2
{
    "abc"
}

Function Save-PrettyDM
{
     write-host "abc"
}

# Public Interface

#Export-ModuleMember -Function Get-DM2
# *****************************************************************************************************