﻿$var1 = ""
$var2 = ""
$var3 = ""
$var4 = ""
Function Load-defaults
{
$var1 = "ABC1"
$var2 = "ABC2"
$var3 = "ABC3"
$var4 = "ABC4"
}